package BD;

import javax.swing.*;
import java.sql.*;
/**
 * exemple de la javadoc
 * @author Youssef
 *
 */

public class ConnectionDB {
	Connection myConn = null;
	
	public static Connection ConnecDb() {
		try {
			Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost/gestion_Club","root", "youssef.987");
			return myConn;
		}catch(Exception e)
		{
			JOptionPane.showConfirmDialog(null, e);
			return null;
		}
	
	}
		
}
