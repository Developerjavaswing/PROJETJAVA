package apps_club;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import BD.ConnectionDB;

import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.Font;
/**
 * exemple de la javadoc
 * @author Youssef
 *
 */

public class MdpOublie extends JFrame {

	private JPanel contentPane;
	private JTextField usertextField;
	private JTextField textField_1;
	Connection MyConn = null;
	PreparedStatement stm = null;
	ResultSet resultat = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MdpOublie frame = new MdpOublie();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MdpOublie() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 412, 122);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		MyConn = ConnectionDB.ConnecDb();
		
		usertextField = new JTextField();
		usertextField.setFont(new Font("Tahoma", Font.PLAIN, 11));
		usertextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				String username = usertextField.getText().toString();
				String sql = "select mdp_ad from admin where nom_ad=?";
				try {
					stm = MyConn.prepareStatement(sql);
					stm.setString(1, username);
					resultat=stm.executeQuery(); //haddi katakhoud lmdp li kayna f requette 
					if(resultat.next()) {
						String pass = resultat.getString("mdp_ad");//had kayaffecter linna password li f resultat l pass
						String pass1 = pass.substring(0, 3);
						
						textField_1.setText(""+pass1+"*****");
						
					}
					
				String sql1 = "select mdp_tr from tresorier where nom_tr=?"; 
				stm = MyConn.prepareStatement(sql1);
				stm.setString(1, username);
				resultat=stm.executeQuery(); //haddi katakhoud lmdp li kayna f requette 
				if(resultat.next()) {
					String pass = resultat.getString("mdp_tr");//had kayaffecter linna password li f resultat l pass
					String pass1 = pass.substring(0, 3);
					
					textField_1.setText(""+pass1+"*****");
					
				}
				
				String sql2 = "select mdp_sg from sg where nom_sg=?"; 
				stm = MyConn.prepareStatement(sql2);
				stm.setString(1, username);
				resultat=stm.executeQuery(); //haddi katakhoud lmdp li kayna f requette 
				if(resultat.next()) {
					String pass = resultat.getString("mdp_sg");//had kayaffecter linna password li f resultat l pass
					String pass1 = pass.substring(0, 3);
					
					textField_1.setText(""+pass1+"*****");
					
				}
				
			
					
	
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		usertextField.setBounds(106, 11, 96, 20);
		contentPane.add(usertextField);
		usertextField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_1.setEnabled(false);
		textField_1.setEditable(false);
		//textField_1.addKeyListener(new KeyAdapter() {
		//});
		textField_1.setColumns(10);
		textField_1.setBounds(106, 42, 259, 20);
		contentPane.add(textField_1);
		
		JLabel lblNewLabel = new JLabel("nom d'utilisateur :");
		lblNewLabel.setBounds(21, 14, 75, 14);
		contentPane.add(lblNewLabel);
	}

}