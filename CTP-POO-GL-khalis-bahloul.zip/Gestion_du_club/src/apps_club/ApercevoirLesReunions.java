package apps_club;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import BD.ConnectionDB;
import net.proteanit.sql.DbUtils;
/**
 * exemple de la javadoc
 * @author Youssef
 *
 */
public class ApercevoirLesReunions extends JFrame {

	private JPanel contentPane;
	private JTable table;
	
	Connection MyConn = null;
	PreparedStatement stm = null;
	ResultSet resultat = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ApercevoirLesReunions frame = new ApercevoirLesReunions();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ApercevoirLesReunions() {
		setResizable(false);
		setTitle("Les r�unions");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 685, 585);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		MyConn = ConnectionDB.ConnecDb();
		
		JButton btnActualiser = new JButton("Voir la table des r\u00E9unions");
		btnActualiser.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnActualiser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateTable();
			}
		});
		btnActualiser.setBounds(180, 11, 294, 50);
		contentPane.add(btnActualiser);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(26, 72, 623, 464);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Membre obj = new Membre();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("C:\\Users\\Youssef\\Desktop\\Retour.PNG"));
		btnNewButton_1.setBounds(10, 11,23, 20);
		contentPane.add(btnNewButton_1);
	}
	public void UpdateTable(){
		String sql = " select * from reunions ";

		try {
						stm = MyConn.prepareStatement(sql);
						resultat=stm.executeQuery();
						table.setModel(DbUtils.resultSetToTableModel(resultat)); //houwa li kaymkn linna n3emroo la table b les donn�es ta3 tale
						
						
		
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		
	}
}
