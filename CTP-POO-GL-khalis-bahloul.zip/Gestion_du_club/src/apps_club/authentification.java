package apps_club;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;




import BD.ConnectionDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
/**
 * exemple de la javadoc
 * @author Youssef
 *
 */
public class authentification extends JFrame {

	private JFrame frame;
	private JTextField usernameField;
	private JLabel lblPassword;
	private JPasswordField passwordField;
	
	Connection MyConn = null;
	PreparedStatement stm = null;
	ResultSet resultat = null;
	private JLabel lblMotDePasse;
	
	void fermer(){
		frame.dispose();
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					authentification window = new authentification();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public authentification() {
		initialize();
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 654, 400);
		frame.setLocationRelativeTo(null);
		frame.setTitle("******GESTION CLUB******");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		MyConn = ConnectionDB.ConnecDb();
		
		usernameField = new JTextField();
		usernameField.setBounds(297, 123, 147, 20);
		frame.getContentPane().add(usernameField);
		usernameField.setColumns(10);
		
		JLabel lblUsername = new JLabel("nom d'utilisateur :");
		lblUsername.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblUsername.setBounds(134, 126, 123, 14);
		frame.getContentPane().add(lblUsername);
		
		lblPassword = new JLabel("mot de passe :");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPassword.setBounds(134, 167, 123, 14);
		frame.getContentPane().add(lblPassword);
		
		JButton btnSeConnecter = new JButton("Se connecter");
		btnSeConnecter.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSeConnecter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nom = usernameField.getText().toString(); //hado ( username + password ) li tapahoum l'utilisateur flwel
				String password = passwordField.getText().toString();
				int i = 0;
				
				if(nom.equals("") || password.equals(""))
					JOptionPane.showMessageDialog(null, "veuillez remplir les champs vides","erreur",JOptionPane.ERROR_MESSAGE);
					
				
				String sql = "select nom_ad, mdp_ad from admin";
					
				try {
					stm = MyConn.prepareStatement(sql);
					resultat = stm.executeQuery();
					//int i = 0;
					
					while(resultat.next()) { //illaa madrnach haddi (resultat.next()) koulma kaytaper l'uilisateur wa7ed l7aref kaytle3 erreur hit f koula 7rf katexecuta l requette machi ta katkmel 3ad kat executa
						String username1 = resultat.getString("nom_ad"); //hado ( username + password ) houma li kayniin f base donn�es
						String password1 = resultat.getString("mdp_ad");
							
							
							
						if(username1.equals(nom) && password1.equals(password)) {
								//JOptionPane.showMessageDialog(null, "Connexion reussite");
							i = 1;
							Administrateur obj = new Administrateur();
							obj.setVisible(true);
							obj.setLocationRelativeTo(null);
							fermer();
								
							}
							
						}
						//if(i==0)
							//JOptionPane.showMessageDialog(null, "connexion echou� , verifiez votre MDP ou USERNAME","",JOptionPane.ERROR_MESSAGE);
						
					}catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				String sql1 = "select nom_sg, mdp_sg from sg";
				
				try {
					stm = MyConn.prepareStatement(sql1);
					resultat = stm.executeQuery();
					//int i = 0;
					
					while(resultat.next()) { //illaa madrnach haddi (resultat.next()) koulma kaytaper l'uilisateur wa7ed l7aref kaytle3 erreur hit f koula 7rf katexecuta l requette machi ta katkmel 3ad kat executa
						String username1 = resultat.getString("nom_sg"); //hado ( username + password ) houma li kayniin f base donn�es
						String password1 = resultat.getString("mdp_sg");
							
						if(username1.equals(nom) && password1.equals(password)) {
							//JOptionPane.showMessageDialog(null, "Connexion reussite");
							i = 1;
							SG obj = new SG();
							obj.setVisible(true);
							obj.setLocationRelativeTo(null);
							fermer();
								
							}
							
							
						}
					

				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				String sql2 = "select nom_tr, mdp_tr from tresorier";
				
				try {
					stm = MyConn.prepareStatement(sql2);
					resultat = stm.executeQuery();
					//int i = 0;
					
					while(resultat.next()) { //illaa madrnach haddi (resultat.next()) koulma kaytaper l'uilisateur wa7ed l7aref kaytle3 erreur hit f koula 7rf katexecuta l requette machi ta katkmel 3ad kat executa
						String username1 = resultat.getString("nom_tr"); //hado ( username + password ) houma li kayniin f base donn�es
						String password1 = resultat.getString("mdp_tr");
							
						if(username1.equals(nom) && password1.equals(password)) {
							//JOptionPane.showMessageDialog(null, "Connexion reussite");
							i = 1;
							Tresorier obj = new Tresorier();
							obj.setVisible(true);
							obj.setLocationRelativeTo(null);
							fermer();
								
							}
								
						}

				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				String sql3 = "select nom, mdp from membres";
				
				try {
					stm = MyConn.prepareStatement(sql3);
					resultat = stm.executeQuery();
					//int i = 0;
					
					while(resultat.next()) { //illaa madrnach haddi (resultat.next()) koulma kaytaper l'uilisateur wa7ed l7aref kaytle3 erreur hit f koula 7rf katexecuta l requette machi ta katkmel 3ad kat executa
						String username1 = resultat.getString("nom"); //hado ( username + password ) houma li kayniin f base donn�es
						String password1 = resultat.getString("mdp");
							
						if(username1.equals(nom) && password1.equals(password)) {
							//JOptionPane.showMessageDialog(null, "Connexion reussite");
							i = 1;
							Membre obj = new Membre();
							obj.setVisible(true);
							obj.setLocationRelativeTo(null);
						    fermer();
								
							}
								
						}

				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				if(i==0)
					JOptionPane.showMessageDialog(null, "connexion echou� , verifiez votre MDP ou NOM D'UTILISATEUR","",JOptionPane.ERROR_MESSAGE);
			}
			
		});
		btnSeConnecter.setBounds(297, 217, 147, 23);
		frame.getContentPane().add(btnSeConnecter);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(297, 164, 147, 20);
		frame.getContentPane().add(passwordField);
		
		lblMotDePasse = new JLabel("Mot de Passe oubli\u00E9 ?");
		lblMotDePasse.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MdpOublie obj = new MdpOublie();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
			}
		});
		lblMotDePasse.setBounds(481, 167, 134, 14);
		frame.getContentPane().add(lblMotDePasse);
	}
}
