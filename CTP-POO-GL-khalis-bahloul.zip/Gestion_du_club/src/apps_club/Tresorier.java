package apps_club;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
/**
 * exemple de la javadoc
 * @author Youssef
 *
 */

public class Tresorier extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tresorier frame = new Tresorier();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Tresorier() {
		setResizable(false);
		setTitle("Tresorier");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 654, 400);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnGestionDesMembres = new JButton("Gestion des cotisations");
		btnGestionDesMembres.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GestionDesCotisations obj = new GestionDesCotisations();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnGestionDesMembres.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnGestionDesMembres.setBounds(185, 36, 249, 129);
		contentPane.add(btnGestionDesMembres);
		
		JButton btnNewButton = new JButton("Gestion des budgets");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DistributionDesbudgets obj = new DistributionDesbudgets();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setBounds(185, 210, 249, 129);
		contentPane.add(btnNewButton);
	
	}

}
