package apps_club;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/**
 * exemple de la javadoc
 * @author Youssef
 *
 */

public class Administrateur extends JFrame {

	private JPanel contentPane;
	void fermer(){
		dispose();
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Administrateur frame = new Administrateur();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Administrateur() {
		setResizable(false);
		setTitle("Administration");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 654, 400);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnGestionDesMembres = new JButton("Gestion des membres");
		btnGestionDesMembres.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GestionDesMembres obj = new GestionDesMembres();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				fermer();
			}
		});
		btnGestionDesMembres.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnGestionDesMembres.setBounds(56, 38, 249, 129);
		contentPane.add(btnGestionDesMembres);
		
		JButton btnGestionDesEvenements = new JButton("Gestion des b\u00E9n\u00E9voles");
		btnGestionDesEvenements.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GestionDesB�n�voles obj = new GestionDesB�n�voles();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				fermer();
			}
		});
		btnGestionDesEvenements.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnGestionDesEvenements.setBounds(357, 38, 249, 129);
		contentPane.add(btnGestionDesEvenements);
		
		JButton btnNewButton = new JButton("Gestion des sponsors");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GestionDesSponsors obj = new GestionDesSponsors();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				fermer();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setBounds(214, 220, 257, 129);
		contentPane.add(btnNewButton);
	}
}
