package apps_club;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import BD.ConnectionDB;
import net.proteanit.sql.DbUtils;
import javax.swing.JTextPane;
/**
 * exemple de la javadoc
 * @author Youssef
 *
 */

public class GetionDesR�unions extends JFrame {

	private JPanel contentPane;
	private JTextField nomfield;
	private JTextField prenomfield;
	private JTable table;
	private JTextPane textPane;
	
	Connection MyConn = null;
	PreparedStatement stm = null;
	ResultSet resultat = null;
	private JTextField mdpfield;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GetionDesR�unions frame = new GetionDesR�unions();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GetionDesR�unions() {
		setResizable(false);
		setTitle("Gestion des r�unions");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 685, 585);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		MyConn = ConnectionDB.ConnecDb();
		
		JLabel lblNewLabel = new JLabel("Id          :");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel.setBounds(141, 45, 80, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblPrenom = new JLabel("Date      :");
		lblPrenom.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPrenom.setBounds(141, 82, 80, 14);
		contentPane.add(lblPrenom);
		
		JLabel lblEmail = new JLabel("Sujet     :");
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblEmail.setBounds(141, 146, 80, 14);
		contentPane.add(lblEmail);
		
		nomfield = new JTextField();
		nomfield.setBounds(231, 42, 163, 20);
		contentPane.add(nomfield);
		nomfield.setColumns(10);
		
		prenomfield = new JTextField();
		prenomfield.setColumns(10);
		prenomfield.setBounds(231, 79, 163, 20);
		contentPane.add(prenomfield);
		JTextPane textPane = new JTextPane();
		textPane.setBounds(231, 140, 163, 88);
		contentPane.add(textPane);
		
		JButton btnNewButton = new JButton("Ajouter reunion");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = nomfield.getText().toString();
				String date = prenomfield.getText().toString();
				String lieu= mdpfield.getText().toString();
				String sujet= textPane.getText().toString();


				String sql = " insert into reunions(id_r,date_r,lieu,sujet) values (?,?,?,?) ";

				try {
					if(!id.equals("") && !date.equals("") && !lieu.equals("")) {//!nom.equals("") && !prenom.equals("") && !email.equals("") && !tel.equals("")
					stm = MyConn.prepareStatement(sql);
					stm.setString(1,id);
					stm.setString(2,date);
					stm.setString(3,lieu);
					stm.setString(4,sujet);
					
					stm.execute(); //.executeUpdate()

					nomfield.setText("");
					prenomfield.setText("");
					mdpfield.setText("");
					textPane.setText("");
					UpdateTable();

					}else{
						JOptionPane.showMessageDialog(null, "remplisez les champs vides");
						}

				}catch(SQLException e1){
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(449, 41, 163, 23);
		contentPane.add(btnNewButton);
		
		JButton btnModifierMembre = new JButton("Modifier reunion");
		btnModifierMembre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ligne = table.getSelectedRow();
				if ( ligne < 0)
				{
					JOptionPane.showMessageDialog(null, "selectionnez une case !");
				}else{
					String id = table.getModel().getValueAt(ligne,0).toString();

					String sql = " update reunions set id_r=?, date_r=?, lieu=?, sujet=? where id_r='"+id+"' ";

					try {
						stm = MyConn.prepareStatement(sql);

						stm.setString(1, nomfield.getText().toString());
						stm.setString(2, prenomfield.getText().toString());
						stm.setString(3, mdpfield.getText().toString());
						stm.setString(4, textPane.getText().toString());
					
						stm.executeUpdate(); //.execute()
						
						nomfield.setText("");
						prenomfield.setText("");
						
						mdpfield.setText("");
						textPane.setText("");
					
						UpdateTable();
					

					}catch(SQLException e1){
						e1.printStackTrace();
						}
				}
			}
		});
		btnModifierMembre.setBounds(449, 89, 163, 23);
		contentPane.add(btnModifierMembre);
		
		JButton btnSupprimerMembre = new JButton("Supprimer reunion");
		btnSupprimerMembre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ligne = table.getSelectedRow();
				if ( ligne < 0)
				{
					JOptionPane.showMessageDialog(null, "selectionnez une case !");
				}else{
					String id = table.getModel().getValueAt(ligne,0).toString();

					String sql = " delete from reunions where id_r='"+id+"' ";

					try {
						int response = JOptionPane.showConfirmDialog(null, "Delete this choice?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);


						if (response != JOptionPane.YES_OPTION) {
							return;
						}else{	

						stm = MyConn.prepareStatement(sql);
						stm.execute(); //.executeUpdate()
						JOptionPane.showMessageDialog(null,"deleted succesfully.", "Deleted",JOptionPane.INFORMATION_MESSAGE);
						nomfield.setText("");
						prenomfield.setText("");
						mdpfield.setText("");
						textPane.setText("");
						
						UpdateTable();
						}

					}catch(SQLException e1){
						e1.printStackTrace();
						}
				}
			}
		});
		btnSupprimerMembre.setBounds(449, 137, 163, 23);
		contentPane.add(btnSupprimerMembre);
		
		JButton btnActualiser = new JButton("Actualiser");
		btnActualiser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateTable();
			}
		});
		btnActualiser.setBounds(70, 231, 133, 23);
		contentPane.add(btnActualiser);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(26, 274, 623, 262);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int ligne = table.getSelectedRow(); //hadda houwaa li kay3tinnaa ra9m dyaal ligne 
				String id = table.getModel().getValueAt(ligne,0).toString(); // jbed liya la valeur f ster li cliquit 3liih // 0 : ra9m d colonne
											     
				String sql = " select * from reunions where id_r ='"+id+"'";

				try {
					stm = MyConn.prepareStatement(sql);
					
					resultat = stm.executeQuery();

					if(resultat.next()) 
					{

						nomfield.setText(resultat.getString("id_r")); //resultat.getString("nom") : la valeur dyal le columns dyal dik la ligne li jbdna mnha requette
						prenomfield.setText(resultat.getString("date_r"));
						mdpfield.setText(resultat.getString("lieu"));
						textPane.setText(resultat.getString("sujet"));

					}

				}catch(SQLException e1){
					e1.printStackTrace();
				}
			}
			
		});
		scrollPane.setViewportView(table);
		
		JLabel lblMdp = new JLabel("Lieu      :");
		lblMdp.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblMdp.setBounds(141, 117, 80, 14);
		contentPane.add(lblMdp);
		
		mdpfield = new JTextField();
		mdpfield.setBounds(231, 110, 163, 20);
		contentPane.add(mdpfield);
		mdpfield.setColumns(10);
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SG obj = new SG();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("C:\\Users\\Youssef\\Desktop\\Retour.PNG"));
		btnNewButton_1.setBounds(10, 11,23, 20);
		contentPane.add(btnNewButton_1);
		
	}
	public void UpdateTable(){
		String sql = " select * from reunions ";

		try {
						stm = MyConn.prepareStatement(sql);
						resultat=stm.executeQuery();
						table.setModel(DbUtils.resultSetToTableModel(resultat)); //houwa li kaymkn linna n3emroo la table b les donn�es ta3 tale
						
						
		
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		
	}	
}
