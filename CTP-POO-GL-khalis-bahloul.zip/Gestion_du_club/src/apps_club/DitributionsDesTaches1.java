package apps_club;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import BD.ConnectionDB;
import net.proteanit.sql.DbUtils;
/**
 * exemple de la javadoc
 * @author Youssef
 *
 */

public class DitributionsDesTaches1 extends JFrame {
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTable table;
	
	Connection MyConn = null;
	PreparedStatement stm = null;
	ResultSet resultat = null;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DitributionsDesTaches1 frame = new DitributionsDesTaches1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DitributionsDesTaches1() {
		setResizable(false);
		setTitle("Gestion des taches");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 605, 486);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		MyConn = ConnectionDB.ConnecDb();
		
		JLabel lblNom = new JLabel("Nom     :");
		lblNom.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNom.setBounds(10, 29, 107, 14);
		contentPane.add(lblNom);
		
		JLabel lblPrenom = new JLabel("prenom :");
		lblPrenom.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPrenom.setBounds(10, 65, 107, 14);
		contentPane.add(lblPrenom);
		
		JLabel lblNewLabel = new JLabel("tache    :");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel.setBounds(10, 103, 107, 14);
		contentPane.add(lblNewLabel);
		
		textField_2 = new JTextField();
		textField_2.setBounds(127, 26, 146, 20);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(127, 62, 146, 20);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(127, 100, 146, 20);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		
		JButton btnModifierCotisation = new JButton("modifier une tache");
		btnModifierCotisation.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnModifierCotisation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String tache = textField_4.getText().toString();
				int ligne = table.getSelectedRow();
				if ( ligne < 0)
				{
					JOptionPane.showMessageDialog(null, "selectionnez une case !");
				}else{
					String id = table.getModel().getValueAt(ligne,0).toString();

					String sql = " update membres set tache=?  where id_membre='"+id+"' ";

					try {
						stm = MyConn.prepareStatement(sql);

						stm.setString(1,tache);
						
						stm.execute(); //.executeUpdate()
						
						textField_2.setText("");
						textField_3.setText("");
						textField_4.setText("");
					
						UpdateTable();
					

					}catch(SQLException e1){
						e1.printStackTrace();
						}
				}
				
			}
		});
		btnModifierCotisation.setBounds(329, 29, 250, 88);
		contentPane.add(btnModifierCotisation);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 177, 569, 260);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int ligne = table.getSelectedRow(); //hadda houwaa li kay3tinnaa ra9m dyaal ligne 
				String id = table.getModel().getValueAt(ligne,0).toString(); // jbed liya la valeur f ster li cliquit 3liih // 0 : ra9m d colonne
											     
				String sql = " select * from membres where id_membre ='"+id+"'";

				try {
					stm = MyConn.prepareStatement(sql);
					
					resultat = stm.executeQuery();

					if(resultat.next()) 
					{

						textField_2.setText(resultat.getString("nom")); //resultat.getString("nom") : la valeur dyal le columns dyal dik la ligne li jbdna mnha requette
						textField_3.setText(resultat.getString("prenom"));
						textField_4.setText(resultat.getString("tache"));
						

					}

				}catch(SQLException e1){
					e1.printStackTrace();
				}
			}
		});
		scrollPane.setViewportView(table);
		
		JButton button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateTable();
			}
		});
		button.setIcon(new ImageIcon("C:\\Users\\Youssef\\Desktop\\actualiser.PNG"));
		button.setBounds(52, 151, 23, 20);
		contentPane.add(button);
		
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SG1 obj = new SG1();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("C:\\Users\\Youssef\\Desktop\\Retour.PNG"));
		btnNewButton_1.setBounds(10, 11,23, 20);
		contentPane.add(btnNewButton_1);
		
		
		
		
	}
	public void UpdateTable(){
		String sql = " select * from membres ";

		try {
						stm = MyConn.prepareStatement(sql);
						resultat=stm.executeQuery();
						table.setModel(DbUtils.resultSetToTableModel(resultat)); //houwa li kaymkn linna n3emroo la table b les donn�es ta3 tale
						
						
		
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
	}

}