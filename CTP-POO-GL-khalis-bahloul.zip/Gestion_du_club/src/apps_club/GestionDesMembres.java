package apps_club;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import BD.ConnectionDB;
import net.proteanit.sql.DbUtils;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
/**
 * exemple de la javadoc
 * @author Youssef
 *
 */

public class GestionDesMembres extends JFrame {

	private JPanel contentPane;
	private JTextField nomfield;
	private JTextField prenomfield;
	private JTextField emailfield;
	private JTextField telfield;
	private JTable table;
	
	Connection MyConn = null;
	PreparedStatement stm = null;
	ResultSet resultat = null;
	private JTextField textField;
	private JTextField mdpfield;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GestionDesMembres frame = new GestionDesMembres();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GestionDesMembres() {
		setResizable(false);
		setTitle("Gestion des membres");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 685, 585);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		MyConn = ConnectionDB.ConnecDb();
		
		JLabel lblNewLabel = new JLabel("Nom       :");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel.setBounds(141, 63, 80, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblPrenom = new JLabel("Prenom :");
		lblPrenom.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPrenom.setBounds(141, 94, 80, 14);
		contentPane.add(lblPrenom);
		
		JLabel lblEmail = new JLabel("email     :");
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblEmail.setBounds(141, 156, 80, 14);
		contentPane.add(lblEmail);
		
		JLabel lblTel = new JLabel("tel          :");
		lblTel.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblTel.setBounds(141, 187, 80, 14);
		contentPane.add(lblTel);
		
		nomfield = new JTextField();
		nomfield.setBounds(231, 60, 163, 20);
		contentPane.add(nomfield);
		nomfield.setColumns(10);
		
		prenomfield = new JTextField();
		prenomfield.setColumns(10);
		prenomfield.setBounds(231, 91, 163, 20);
		contentPane.add(prenomfield);
		
		emailfield = new JTextField();
		emailfield.setColumns(10);
		emailfield.setBounds(231, 153, 163, 20);
		contentPane.add(emailfield);
		
		telfield = new JTextField();
		telfield.setColumns(10);
		telfield.setBounds(231, 184, 163, 20);
		contentPane.add(telfield);
		textField = new JTextField();
		textField.setBounds(233, 29, 161, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblId = new JLabel("ID        :");
		lblId.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblId.setBounds(141, 32, 41, 14);
		contentPane.add(lblId);
		
		JButton btnNewButton = new JButton("Ajouter membre");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nom = nomfield.getText().toString();
				String prenom = prenomfield.getText().toString();
				String email = emailfield.getText().toString();
				String tel = telfield.getText().toString();
				String id= textField.getText().toString();
				String mdp= mdpfield.getText().toString();


				String sql = " insert into membres(id_membre,nom,prenom,mdp,Email,tel) values (?,?,?,?,?,?) ";

				try {
					if(!nom.equals("") && !prenom.equals("") && !id.equals("")) {//!nom.equals("") && !prenom.equals("") && !email.equals("") && !tel.equals("")
					stm = MyConn.prepareStatement(sql);
					stm.setString(1,id);
					stm.setString(2,nom);
					stm.setString(3,prenom);
					stm.setString(4,mdp);
					stm.setString(5,email);
					stm.setString(6,tel);
					
					
					stm.execute(); //.executeUpdate()

					nomfield.setText("");
					prenomfield.setText("");
					emailfield.setText("");
					telfield.setText("");
					textField.setText("");
					mdpfield.setText("");
					
					UpdateTable();

					}else{
						JOptionPane.showMessageDialog(null, "remplisez les champs vides");
						}

				}catch(SQLException e1){
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(449, 41, 163, 23);
		contentPane.add(btnNewButton);
		
		JButton btnModifierMembre = new JButton("Modifier membre");
		btnModifierMembre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ligne = table.getSelectedRow();
				if ( ligne < 0)
				{
					JOptionPane.showMessageDialog(null, "selectionnez un membre !");
				}else{
					String id = table.getModel().getValueAt(ligne,0).toString();

					String sql = " update membres set id_membre=?,nom=?, prenom=?,mdp=?, email=?, tel=? where id_membre='"+id+"' ";

					try {
						stm = MyConn.prepareStatement(sql);
						
						
						stm.setString(1,textField.getText().toString());
						stm.setString(2, nomfield.getText().toString());
						stm.setString(3, prenomfield.getText().toString());
						stm.setString(4, mdpfield.getText().toString());
						stm.setString(5, emailfield.getText().toString());
						stm.setString(6, telfield.getText().toString());
						
					
						stm.executeUpdate(); //.execute()
						
						nomfield.setText("");
						prenomfield.setText("");
						emailfield.setText("");
						telfield.setText("");
						textField.setText("");
						mdpfield.setText("");
					
						UpdateTable();
					

					}catch(SQLException e1){
						e1.printStackTrace();
						}
				}
			}
		});
		btnModifierMembre.setBounds(449, 89, 163, 23);
		contentPane.add(btnModifierMembre);
		
		JButton btnSupprimerMembre = new JButton("Supprimer membre");
		btnSupprimerMembre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ligne = table.getSelectedRow();
				if ( ligne < 0)
				{
					JOptionPane.showMessageDialog(null, "selectionnez un membre !");
				}else{
					String id = table.getModel().getValueAt(ligne,0).toString();

					String sql = " delete from membres where id_membre='"+id+"' ";

					try {
						int response = JOptionPane.showConfirmDialog(null, "Delete this member?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);


						if (response != JOptionPane.YES_OPTION) {
							return;
						}else{	

						stm = MyConn.prepareStatement(sql);
						stm.execute(); //.executeUpdate()
						JOptionPane.showMessageDialog(null,"member deleted succesfully.", "Employee Deleted",JOptionPane.INFORMATION_MESSAGE);
						nomfield.setText("");
						prenomfield.setText("");
						emailfield.setText("");
						telfield.setText("");
						textField.setText("");
						mdpfield.setText("");
						UpdateTable();
						}

					}catch(SQLException e1){
						e1.printStackTrace();
						}
				}
			}
		});
		btnSupprimerMembre.setBounds(449, 131, 163, 23);
		contentPane.add(btnSupprimerMembre);
		
		JButton btnActualiser = new JButton("Actualiser");
		btnActualiser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateTable();
			}
		});
		btnActualiser.setBounds(71, 210, 133, 23);
		contentPane.add(btnActualiser);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(26, 244, 623, 292);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int ligne = table.getSelectedRow(); //hadda houwaa li kay3tinnaa ra9m dyaal ligne 
				String id = table.getModel().getValueAt(ligne,0).toString(); // jbed liya la valeur f ster li cliquit 3liih // 0 : ra9m d colonne
											     
				String sql = " select * from membres where id_membre ='"+id+"'";

				try {
					stm = MyConn.prepareStatement(sql);
					
					resultat = stm.executeQuery();

					if(resultat.next()) 
					{

						nomfield.setText(resultat.getString("nom")); //resultat.getString("nom") : la valeur dyal le columns dyal dik la ligne li jbdna mnha requette
						prenomfield.setText(resultat.getString("prenom"));
						emailfield.setText(resultat.getString("Email")); 
						telfield.setText(resultat.getString("tel"));
						textField.setText(resultat.getString("id_membre"));
						mdpfield.setText(resultat.getString("mdp"));
						

					}

				}catch(SQLException e1){
					e1.printStackTrace();
				}
			}
			
		});
		scrollPane.setViewportView(table);
		
		JLabel lblMdp = new JLabel("mdp      :");
		lblMdp.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblMdp.setBounds(141, 119, 63, 26);
		contentPane.add(lblMdp);
		
		mdpfield = new JTextField();
		mdpfield.setBounds(231, 122, 163, 20);
		contentPane.add(mdpfield);
		mdpfield.setColumns(10);
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Administrateur obj = new Administrateur();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("C:\\Users\\Youssef\\Desktop\\Retour.PNG"));
		btnNewButton_1.setBounds(10, 11,23, 20);
		contentPane.add(btnNewButton_1);
		
		
	}
	public void UpdateTable(){
		String sql = " select * from membres ";

		try {
						stm = MyConn.prepareStatement(sql);
						resultat=stm.executeQuery();
						table.setModel(DbUtils.resultSetToTableModel(resultat)); //houwa li kaymkn linna n3emroo la table b les donn�es ta3 tale
						
						
		
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		
	}
}
