package apps_club;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import BD.ConnectionDB;
import net.proteanit.sql.DbUtils;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
/**
 * exemple de la javadoc
 * @author Youssef
 *
 */

public class GestionDesAbsences extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTable table;
	
	Connection MyConn = null;
	PreparedStatement stm = null;
	ResultSet resultat = null;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GestionDesAbsences frame = new GestionDesAbsences();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GestionDesAbsences() {
		setResizable(false);
		setTitle("Gestion des absences");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 605, 486);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		MyConn = ConnectionDB.ConnecDb();
		
		JLabel lblNom = new JLabel("Nom   :");
		lblNom.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNom.setBounds(10, 29, 107, 14);
		contentPane.add(lblNom);
		
		JLabel lblPrenom = new JLabel("prenom :");
		lblPrenom.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPrenom.setBounds(10, 65, 107, 14);
		contentPane.add(lblPrenom);
		
		JLabel lblNewLabel = new JLabel("nbr d'absences :");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel.setBounds(10, 103, 107, 14);
		contentPane.add(lblNewLabel);
		
		textField_2 = new JTextField();
		textField_2.setBounds(127, 26, 96, 20);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(127, 62, 96, 20);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"","0", "1", "2","3"}));
		comboBox.setBounds(127, 99, 96, 22);
		contentPane.add(comboBox);
		
		JLabel lblRechercheParCategorie = new JLabel("recherche par cat\u00E9gorie :");
		lblRechercheParCategorie.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblRechercheParCategorie.setBounds(261, 103, 174, 14);
		contentPane.add(lblRechercheParCategorie);
		
		JComboBox comboBox_Rech = new JComboBox();
		comboBox_Rech.setModel(new DefaultComboBoxModel(new String[] {"","nom", "prenom", "nbrAbs"}));
		comboBox_Rech.setBounds(445, 99, 104, 22);
		contentPane.add(comboBox_Rech);
		
		JButton btnNewButton = new JButton("rechercher");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textField_4.getText().equals("")) {
		            JOptionPane.showMessageDialog(null, "SVP entrer quelque chose");
		        } else {
		            if (comboBox_Rech.getSelectedItem().equals("nom")) {
		                try {
							stm = MyConn.prepareStatement("select * from membres where nom LIKE '%" + textField_4.getText() + "%' ");
							resultat = stm.executeQuery();
			                table.setModel(DbUtils.resultSetToTableModel(resultat));
			                textField_4.setText("");
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
		                
		            } else if (comboBox_Rech.getSelectedItem().equals("prenom")) {
		            	try {
							stm = MyConn.prepareStatement("select * from membres where prenom LIKE '%" + textField_4.getText() + "%' ");
							resultat = stm.executeQuery();
			                table.setModel(DbUtils.resultSetToTableModel(resultat));
			                textField_4.setText("");
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
		                
		            } else if (comboBox_Rech.getSelectedItem().equals("nbrAbs")) {
		            	try {
							stm = MyConn.prepareStatement("select * from membres where nbr_Absence LIKE '%" + textField_4.getText() + "%' ");
							resultat = stm.executeQuery();
			                table.setModel(DbUtils.resultSetToTableModel(resultat));
			                textField_4.setText("");
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
		                
		            } 
		        }
				
			}
		});
		btnNewButton.setBounds(261, 140, 138, 23);
		contentPane.add(btnNewButton);
		
		JButton btnModifierCotisation = new JButton("modifier nbr d'absences");
		btnModifierCotisation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ligne = table.getSelectedRow();
				if ( ligne < 0)
				{
					JOptionPane.showMessageDialog(null, "selectionnez un membre !");
				}else{
					String id = table.getModel().getValueAt(ligne,0).toString();

					String sql = " update membres set nbr_Absence=?  where id_membre='"+id+"' ";

					try {
						stm = MyConn.prepareStatement(sql);

						stm.setString(1, comboBox.getSelectedItem().toString());
						
						stm.execute(); //.executeUpdate()
						
						textField_2.setText("");
						textField_3.setText("");
						comboBox.setSelectedItem("");
					
						UpdateTable();
					

					}catch(SQLException e1){
						e1.printStackTrace();
						}
				}
				
			}
		});
		btnModifierCotisation.setBounds(261, 61, 174, 23);
		contentPane.add(btnModifierCotisation);
		
		JButton btnSupprimerMembre = new JButton("Supprimer membre");
		btnSupprimerMembre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ligne = table.getSelectedRow();
				if ( ligne < 0)
				{
					JOptionPane.showMessageDialog(null, "selectionnez un membre !");
				}else{
					String id = table.getModel().getValueAt(ligne,0).toString();

					String sql = " delete from membres where id_membre='"+id+"' ";

					try {
						int response = JOptionPane.showConfirmDialog(null, "Delete this member?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);


						if (response != JOptionPane.YES_OPTION) {
							return;
						}else{	

						stm = MyConn.prepareStatement(sql);
						stm.execute(); //.executeUpdate()
						JOptionPane.showMessageDialog(null,"member deleted succesfully.", "Employee Deleted",JOptionPane.INFORMATION_MESSAGE);
						UpdateTable();
						textField_2.setText("");
						textField_3.setText("");
						comboBox.setSelectedItem("");
						}

					}catch(SQLException e1){
						e1.printStackTrace();
						}
				}
			}
		});
		btnSupprimerMembre.setBounds(261, 25, 174, 23);
		contentPane.add(btnSupprimerMembre);
		
		textField_4 = new JTextField();
		textField_4.setBounds(445, 141, 104, 20);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 177, 569, 260);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int ligne = table.getSelectedRow(); //hadda houwaa li kay3tinnaa ra9m dyaal ligne 
				String id = table.getModel().getValueAt(ligne,0).toString(); // jbed liya la valeur f ster li cliquit 3liih // 0 : ra9m d colonne
											     
				String sql = " select * from membres where id_membre ='"+id+"'";

				try {
					stm = MyConn.prepareStatement(sql);
					
					resultat = stm.executeQuery();

					if(resultat.next()) 
					{

						textField_2.setText(resultat.getString("nom")); //resultat.getString("nom") : la valeur dyal le columns dyal dik la ligne li jbdna mnha requette
						textField_3.setText(resultat.getString("prenom"));
						comboBox.setSelectedItem(resultat.getString("nbr_Absence"));
						

					}

				}catch(SQLException e1){
					e1.printStackTrace();
				}
			}
		});
		scrollPane.setViewportView(table);
		
		JButton button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateTable();
			}
		});
		button.setIcon(new ImageIcon("C:\\Users\\Youssef\\Desktop\\actualiser.PNG"));
		button.setBounds(52, 151, 23, 20);
		contentPane.add(button);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SG obj = new SG();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("C:\\Users\\Youssef\\Desktop\\Retour.PNG"));
		btnNewButton_1.setBounds(10, 11,23, 20);
		contentPane.add(btnNewButton_1);
		
		
		
		
	}
	public void UpdateTable(){
		String sql = " select * from membres ";

		try {
						stm = MyConn.prepareStatement(sql);
						resultat=stm.executeQuery();
						table.setModel(DbUtils.resultSetToTableModel(resultat)); //houwa li kaymkn linna n3emroo la table b les donn�es ta3 tale
						
						
		
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
	}

}
	
		
