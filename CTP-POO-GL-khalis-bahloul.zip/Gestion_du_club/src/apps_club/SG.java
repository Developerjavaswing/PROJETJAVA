package apps_club;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
/**
 * exemple de la javadoc
 * @author Youssef
 *
 */

public class SG extends JFrame {

	private JPanel contentPane;
	
	/*void fermer(){
		dispose();
	}*/

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SG frame = new SG();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SG()  {
		setResizable(false);
		setTitle("Secr\u00E9taire g\u00E9n\u00E9rale");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 654, 400);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnGestionDesMembres = new JButton("Gestion des absences");
		btnGestionDesMembres.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GestionDesAbsences obj = new GestionDesAbsences();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnGestionDesMembres.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnGestionDesMembres.setBounds(39, 38, 249, 129);
		contentPane.add(btnGestionDesMembres);
		
		JButton btnGestionDesEvenements = new JButton("Gestion des r\u00E9unions");
		btnGestionDesEvenements.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GetionDesR�unions obj = new GetionDesR�unions();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				dispose();
				
			}
		});
		btnGestionDesEvenements.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnGestionDesEvenements.setBounds(357, 38, 249, 129);
		contentPane.add(btnGestionDesEvenements);
		
		JButton btnNewButton = new JButton("Distribution des taches");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SG1 obj = new SG1();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setBounds(185, 223, 249, 116);
		contentPane.add(btnNewButton);
	}
}
