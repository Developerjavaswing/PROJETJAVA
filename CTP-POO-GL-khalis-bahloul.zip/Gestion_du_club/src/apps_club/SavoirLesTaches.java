package apps_club;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import BD.ConnectionDB;
import net.proteanit.sql.DbUtils;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
/**
 * exemple de la javadoc
 * @author Youssef
 *
 */

public class SavoirLesTaches extends JFrame {

	private JPanel contentPane;
	private JTable table;
	
	Connection MyConn = null;
	PreparedStatement stm = null;
	ResultSet resultat = null;
	private JLabel lblNewLabel;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SavoirLesTaches frame = new SavoirLesTaches();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SavoirLesTaches() {
		setResizable(false);
		setTitle("Savoir les taches");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 685, 585);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		MyConn = ConnectionDB.ConnecDb();
		
		JButton btnActualiser = new JButton("Voir les taches");
		btnActualiser.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnActualiser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateTable();
			}
		});
		btnActualiser.setBounds(355, 11, 294, 20);
		contentPane.add(btnActualiser);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(26, 67, 623, 469);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		lblNewLabel = new JLabel("Entrer le mdp:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel.setBounds(40, 14, 99, 14);
		contentPane.add(lblNewLabel);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(147, 11, 117, 20);
		contentPane.add(passwordField);
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Membre obj = new Membre();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("C:\\Users\\Youssef\\Desktop\\Retour.PNG"));
		btnNewButton_1.setBounds(10, 11,23, 20);
		contentPane.add(btnNewButton_1);
		
	}
	public void UpdateTable(){
		String sql = " select * from membres ";

		try {
						stm = MyConn.prepareStatement("select * from membres where mdp LIKE '%" + passwordField.getText() + "%' ");
						resultat=stm.executeQuery();
						table.setModel(DbUtils.resultSetToTableModel(resultat)); //houwa li kaymkn linna n3emroo la table b les donn�es ta3 tale
						
						
		
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		
	}
}
