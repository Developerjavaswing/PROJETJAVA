package apps_club;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
/**
 * exemple de la javadoc
 * @author Youssef
 *
 */

public class Membre extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Membre frame = new Membre();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Membre() {
		setResizable(false);
		setTitle("Membre");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 654, 400);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnGestionDesMembres = new JButton("Apercevoir les r\u00E9unions");
		btnGestionDesMembres.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ApercevoirLesReunions obj = new ApercevoirLesReunions();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnGestionDesMembres.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnGestionDesMembres.setBounds(185, 36, 249, 129);
		contentPane.add(btnGestionDesMembres);
		
		JButton btnNewButton = new JButton("Savoir les taches");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SavoirLesTaches obj = new SavoirLesTaches();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setBounds(185, 210, 249, 129);
		contentPane.add(btnNewButton);
	
	}

}
