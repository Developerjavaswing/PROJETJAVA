Pour commencer l'application vous devez executer la classe "authentification" et entrez le "nom" 
et le "mdp" situ�s dans le fichier DB.sql .Et il y a une sch�ma de la structure de l'application 
sur le rapport qui facilite l'utisation de cette application
