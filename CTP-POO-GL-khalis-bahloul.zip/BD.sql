-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  ven. 31 mai 2019 à 18:52
-- Version du serveur :  10.1.28-MariaDB
-- Version de PHP :  7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `gestion_club`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `nom_ad` varchar(64) DEFAULT NULL,
  `prenom_ad` varchar(64) DEFAULT NULL,
  `mdp_ad` varchar(64) DEFAULT NULL,
  `email_ad` varchar(64) DEFAULT NULL,
  `tel_ad` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id_admin`, `nom_ad`, `prenom_ad`, `mdp_ad`, `email_ad`, `tel_ad`) VALUES
(1, 'bahloul', 'youssef', 'admin.987', 'youssefbahloul98@gmail.com', '0651594187'),
(2, 'khalis', 'oualid', 'admin.987', 'khalisoualid98@gmail.com', '0615594121');

-- --------------------------------------------------------

--
-- Structure de la table `benevoles`
--

CREATE TABLE `benevoles` (
  `id_b` int(11) NOT NULL,
  `nom` varchar(10) NOT NULL,
  `prenom` varchar(10) NOT NULL,
  `email` varchar(25) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `tache` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `benevoles`
--

INSERT INTO `benevoles` (`id_b`, `nom`, `prenom`, `email`, `tel`, `tache`) VALUES
(1, 'aziz', 'mohammed', 'aziz@hotmail.fr', '0654798884', 'logistique'),
(2, 'bahloul', 'youssef', 'bahlouyoussef@hotmail.fr', '0654798884', 'media');

-- --------------------------------------------------------

--
-- Structure de la table `cotisations`
--

CREATE TABLE `cotisations` (
  `id_cotisation` int(11) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `cotisé` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `cotisations`
--

INSERT INTO `cotisations` (`id_cotisation`, `nom`, `prenom`, `cotisé`) VALUES
(1, 'bahloul', 'youssef', 'oui'),
(2, 'khalis', 'oualid', 'oui'),
(3, 'mami', 'zayd', 'oui'),
(4, 'essabri', 'hamza', 'non');

-- --------------------------------------------------------

--
-- Structure de la table `membres`
--

CREATE TABLE `membres` (
  `id_membre` int(11) NOT NULL,
  `nom` varchar(25) NOT NULL,
  `prenom` varchar(25) NOT NULL,
  `mdp` varchar(20) NOT NULL,
  `email` varchar(25) DEFAULT NULL,
  `tel` varchar(25) DEFAULT NULL,
  `tache` varchar(60) DEFAULT NULL,
  `cotisation` varchar(20) DEFAULT NULL,
  `nbr_Absence` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `membres`
--

INSERT INTO `membres` (`id_membre`, `nom`, `prenom`, `mdp`, `email`, `tel`, `tache`, `cotisation`, `nbr_Absence`) VALUES
(1, 'mami', 'zayd', 'mami.123', 'mamizayd@gmail.com', '0628285165', 'sonorisation', 'oui', '0'),
(2, 'moukrim', 'abdsamad', 'moukrim.123', 'abdsamadmourim@gmail.com', '0641789632', 'communication', 'non', '1'),
(3, 'essabri', 'hamza', 'essabri.123', 'essabrihamza@gmail.com', '0610067381', 'gestion', 'oui', '2'),
(4, 'diouri', 'abdelhamid', 'diouri.123', 'diouriadel@gmail.com', '0654878952', 'logistique', 'non', '2');

-- --------------------------------------------------------

--
-- Structure de la table `reunions`
--

CREATE TABLE `reunions` (
  `id_r` int(11) NOT NULL,
  `date_r` date DEFAULT NULL,
  `lieu` varchar(30) DEFAULT NULL,
  `sujet` varchar(900) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `reunions`
--

INSERT INTO `reunions` (`id_r`, `date_r`, `lieu`, `sujet`) VALUES
(1, '2019-09-01', 'sos village', 'présentation des membres'),
(2, '2019-09-07', 'sos village', 'lancement du travail'),
(3, '2019-09-15', 'sos village', 'déroulement du projet');

-- --------------------------------------------------------

--
-- Structure de la table `sg`
--

CREATE TABLE `sg` (
  `id_sg` int(11) NOT NULL,
  `nom_sg` varchar(64) DEFAULT NULL,
  `prenom_sg` varchar(64) DEFAULT NULL,
  `mdp_sg` varchar(64) DEFAULT NULL,
  `email_sg` varchar(64) DEFAULT NULL,
  `tel_sg` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `sg`
--

INSERT INTO `sg` (`id_sg`, `nom_sg`, `prenom_sg`, `mdp_sg`, `email_sg`, `tel_sg`) VALUES
(1, 'mami', 'zayd', 'fifo.123', 'mamizayd@gmail.com', '0661784512'),
(2, 'essabri', 'hamza', 'fifo.123', 'essabrihamza98@gmail.com', '0661478521');

-- --------------------------------------------------------

--
-- Structure de la table `sponsors`
--

CREATE TABLE `sponsors` (
  `id_s` int(11) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `type` varchar(10) DEFAULT NULL,
  `budget` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `sponsors`
--

INSERT INTO `sponsors` (`id_s`, `nom`, `type`, `budget`) VALUES
(1, 'CIH', 'platinum', '150000dh'),
(2, 'Sidi Ali', 'gold', '55555dh');

-- --------------------------------------------------------

--
-- Structure de la table `tresorier`
--

CREATE TABLE `tresorier` (
  `id_tr` int(11) NOT NULL,
  `nom_tr` varchar(64) DEFAULT NULL,
  `prenom_tr` varchar(64) DEFAULT NULL,
  `mdp_tr` varchar(64) DEFAULT NULL,
  `email_tr` varchar(64) DEFAULT NULL,
  `tel_tr` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tresorier`
--

INSERT INTO `tresorier` (`id_tr`, `nom_tr`, `prenom_tr`, `mdp_tr`, `email_tr`, `tel_tr`) VALUES
(1, 'aziz', 'mohamed', '123456', 'azizmohamed@gmail.com', '0632547852'),
(2, 'ouarrad', 'youssef', '147852', 'ouarradyoussef@gmail.com', '0652211478');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Index pour la table `benevoles`
--
ALTER TABLE `benevoles`
  ADD PRIMARY KEY (`id_b`);

--
-- Index pour la table `cotisations`
--
ALTER TABLE `cotisations`
  ADD PRIMARY KEY (`id_cotisation`);

--
-- Index pour la table `membres`
--
ALTER TABLE `membres`
  ADD PRIMARY KEY (`id_membre`);

--
-- Index pour la table `reunions`
--
ALTER TABLE `reunions`
  ADD PRIMARY KEY (`id_r`);

--
-- Index pour la table `sg`
--
ALTER TABLE `sg`
  ADD PRIMARY KEY (`id_sg`);

--
-- Index pour la table `sponsors`
--
ALTER TABLE `sponsors`
  ADD PRIMARY KEY (`id_s`);

--
-- Index pour la table `tresorier`
--
ALTER TABLE `tresorier`
  ADD PRIMARY KEY (`id_tr`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `cotisations`
--
ALTER TABLE `cotisations`
  MODIFY `id_cotisation` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `sg`
--
ALTER TABLE `sg`
  MODIFY `id_sg` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `tresorier`
--
ALTER TABLE `tresorier`
  MODIFY `id_tr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
